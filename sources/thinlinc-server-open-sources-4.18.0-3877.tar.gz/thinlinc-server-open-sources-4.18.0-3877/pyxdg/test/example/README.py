# This file should be detected as text/x-python, as the *.py glob has a 
# greater weight than the readme* glob.
