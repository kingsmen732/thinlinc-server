Exceptions
==========

.. automodule:: xdg.Exceptions
   :members:
