/*
 * Copyright 2013-2014 Pierre Ossman for Cendio AB
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include "includes.h"

#ifdef WIN32

int
readv(int fd, struct iovec *iov, int iovcnt)
{
	errno = EINVAL;
	return -1;
}

void
openlog(const char *ident, int option, int facility)
{
}

void
syslog(int priority, const char *format, ...)
{
}

void
closelog(void)
{
}

pid_t
fork(void)
{
	errno = EINVAL;
	return -1;
}

int
chown(const char *pathname, uid_t owner, gid_t group)
{
    errno = EINVAL;
    return -1;
}

int
setpgrp(pid_t pid, pid_t pgid)
{
	errno = EINVAL;
	return -1;
}

int
link(const char *path1, const char *path2)
{
	errno = EINVAL;
	return -1;
}

int
pipe(int pipefd[2])
{
	errno = EINVAL;
	return -1;
}

int
getdtablesize(void)
{
	errno = EINVAL;
	return -1;
}

pid_t
wait4(pid_t pid, int *status, int options, struct rusage *rusage)
{
	errno = EINVAL;
	return -1;
}

#endif /* WIN32 */
