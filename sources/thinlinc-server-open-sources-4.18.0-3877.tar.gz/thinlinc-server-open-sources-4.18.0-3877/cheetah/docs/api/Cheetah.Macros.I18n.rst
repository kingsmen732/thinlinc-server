Cheetah\.Macros\.I18n module
============================

.. automodule:: Cheetah.Macros.I18n
    :members:
    :undoc-members:
    :show-inheritance:
