Cheetah\.convertTmplPathToModuleName module
===========================================

.. automodule:: Cheetah.convertTmplPathToModuleName
    :members:
    :undoc-members:
    :show-inheritance:
